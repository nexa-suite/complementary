# Operations Mobile Android Construction

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 03-mobile/architecture; 03-mobile/product; 01-shared/engineering/quality; 01-shared/security
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

Accepted TARGET: Android, Kotlin 2.4.20, Jetpack Compose BOM 2026.09.00, AGP 9.4.x, Gradle 9.6.x, JDK 17, compile/target SDK 37 and min SDK 29. This does not alter API Java 25.

Use Hilt, Jetpack Navigation 3 stable 1.1.x, CameraX and ML Kit Barcode Scanning bundled model. Manual identification fallback is mandatory. DataStore holds small settings/context metadata; Room is a justified cache/staging store only; Keystore protects local key material; WorkManager supports safe persistent retry. No local store is business authority, generic offline synchronization, permanent driver GPS tracking or server-domain duplication.

One Operations C4 container may use a small feature/client-responsibility module direction: `:app`, `feature:access`, `feature:warehouse`, `feature:dispatch`, `feature:delivery`, and core network/database/security/design-system/testing. Presentation must not directly invoke HTTP implementations or Room DAOs.
