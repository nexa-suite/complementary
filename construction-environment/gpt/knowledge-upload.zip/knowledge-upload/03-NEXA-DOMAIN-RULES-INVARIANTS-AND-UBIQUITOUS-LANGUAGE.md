# Domain Rules, Invariants and Ubiquitous Language

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 01-shared/domain; 01-shared/data/transaction-concurrency-matrix.md
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

Core Domain: Sales Commitment, Inventory Availability, and Fulfillment & Delivery. Strong invariants use the smallest correct persistence mechanism: revision/CAS for stale mutable state, conditional update or row lock for scarce resources, deterministic lock ordering, durable idempotency and explicit conflict outcomes.

Authoritative state and durable outbox rows are inserted in the same local transaction. The asynchronous publisher reads only committed outbox rows and publishes at-least-once; consumers tolerate duplicates where needed. Exactly-once transport is not claimed.

Business history remains immutable where required. Corrections and reversals create explicit evidence rather than silently rewriting issued documents, confirmed payments, inventory movements or traceability facts.
