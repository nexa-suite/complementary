# Nexa Knowledge Index

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: README.md; 01-shared; 03-mobile; 90-academic/mobile/course-1acc0238
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

This is a fast navigation layer, not an independent architecture source. Deep evidence is in ZIP 15–19.

## Authority

1. Explicit accepted Owner decision.
2. Current canonical Blueprint represented by this pack (ee3aaaf3c55bc0a4dfa5706a2ef82171970133db).
3. Verified modern implementation.
4. Current Design evidence.
5. Academic rubric for academic compliance only.
6. Foundational references/books.
7. Historical/legacy evidence.

If two knowledge files appear inconsistent, apply this authority map, consult provenance, and do not average answers. DDD or Scrum books never become Nexa Product authority.

## Pack map

- 01–04: governance, product and strategic domain.
- 05–09: tactical model, data, C4, reliability and security.
- 10–12: accepted Operations and Buyer construction baselines.
- 13–14: academic evidence and local construction gates.
- Deep evidence: `15-NEXA-ACADEMIC-AND-FOUNDATIONAL-SOURCES.zip`, `16-NEXA-C4-CANONICAL.zip`, `17-NEXA-DDD-UML-AND-DOMAIN-STORIES-CANONICAL.zip`, `18-NEXA-DATA-POSTGRESQL-ERD-CANONICAL.zip`, `19-NEXA-MOBILE-CONSTRUCTION-SOURCES.zip`.

The synchronized Mobile Report commit is 216d449b265be448f3275d8f64f7afcc2a032309; Blueprint remains authoritative.
