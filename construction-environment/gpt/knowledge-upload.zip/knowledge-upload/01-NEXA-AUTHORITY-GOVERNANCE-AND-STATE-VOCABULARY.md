# Authority, Governance and State Vocabulary

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: README.md; 01-shared/architecture; 01-shared/domain; 01-shared/security
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

Nexa is a B2B multi-tenant SaaS for importers and distributors with a strong cold-chain operations specialization. It is one C4 Software System, a Spring Boot modular monolith, and one shared authoritative PostgreSQL TARGET model.

Use status words precisely: **AS-IS** is verified current implementation evidence; **TARGET** is accepted construction direction; **FUTURE** is intentionally deferred; **OPEN** is an unresolved decision; **HISTORICAL** is provenance only. A technology decision is not implementation, technical verification, Product Acceptance, System Acceptance, or Production Readiness.

Tenant is the maximum business/data isolation boundary. Tenant is not Workspace. Missing scope fails closed. Human Identity, Workforce Membership, Buyer Relationship and Customer Account are separate concepts.

Keep → Refine → Rework is the default. Rewrite requires extraordinary evidence. Do not derive a Bounded Context from a client, module, package, schema, device or screen.
