# C4 Runtime, Deployment and System Boundaries

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 01-shared/architecture/c4; 01-shared/architecture; 03-mobile/architecture
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

Nexa remains one C4 Software System. TARGET client containers include Operations Mobile and Buyer Mobile, each with one C4 container. Gradle modules and Flutter features are implementation boundaries, not Bounded Contexts or deployment units.

The canonical Structurizr DSL lives in Blueprint. The local rendering runtime lives separately at `complementary/structurizr` with Compose project `nexa-blueprint-architecture`; it reads the one canonical model and is not a second semantic source. It is not part of the Nexa runtime C4.

The C4 archive contains L1, L2, selective L3, seven Dynamic Views, deployment, styles and current SVG/PNG representations. AS-IS, TARGET and FUTURE remain visibly distinct.
