# Buyer Mobile Flutter Construction

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 03-mobile/architecture; 03-mobile/product; 01-shared/engineering/quality; 01-shared/security
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

Accepted TARGET: Flutter 3.47.2, Dart 3.13.x, Android and iOS only. Android construction baseline: min API 24, compile API 37, target API 36; API 37 target compatibility is an acceptance hardening gate. iOS minimum is 15.

Use provider for dependency injection/state contract and go_router for navigation. Prefer Views/Widgets → ViewModels → Repositories → Services, immutable models, commands/actions and selective client use cases only where complexity/reuse warrants. Flutter client orchestration never becomes authority for sales orders, delivery, payments, inventory, credit or authorization.

Feature-first direction: `app/routing`, `app/dependency_injection`, `app/bootstrap`, `core/api`, `core/security`, `core/design_system`, `core/errors`, and delivery/handoff/receipt/discrepancy/access features. Do not add a backend Aggregate-shaped `domain/entities` layer. Swift Package Manager is the modern default for Flutter 3.44+ native dependencies; CocoaPods remains compatibility tooling.
