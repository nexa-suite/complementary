# Product Actors, Roles, Capabilities and Surfaces

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 02-product; 03-mobile/product; 01-shared/architecture/c4
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

Nexa serves tenant-scoped workforces and buyer relationships. Operations Mobile is an accepted TARGET workforce surface for access, warehouse, dispatch and delivery work. Buyer Mobile is an accepted TARGET buyer surface for delivery, handoff, receipt and discrepancy work. Platform, Portal and Website remain distinct client surfaces; none owns server business truth.

Product vocabulary is deliberate: Product is not SKU; Draft is not Purchase Request or Sales Order; Commercial Commitment is not Inventory Backing or Physical Allocation; Safety Stock is not a Reservation; Payment Reported is not Payment Confirmed; Driver Outcome is not Buyer Receipt; Notification is not Business Traceability or Security Audit.

Mobile clients request authoritative API decisions. Local intent or cache persistence does not establish business success.
