# Scrum, Academic Rubric, Backlog and Evidence

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 90-academic/mobile/course-1acc0238; 03-mobile; 02-product
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

The current mobile academic projection is evidence planning, not Product or architecture authority. The current rubric V4 controls academic compliance only. The academic record follows accepted targets: Operations uses Android/Kotlin/Compose; Buyer uses Flutter/Dart for Android+iOS. KMP is evaluated historical provenance. The SPIKE-002 framework-selection question is closed/superseded; device, provider, compatibility and physical-device evidence remain separate research/evidence concerns.

Scrum supports planning and empirical process. It does not redefine Nexa aggregate boundaries, database authority or client/server authority. Story/backlog evidence must distinguish planning, implementation, technical verification, Product Acceptance, System Acceptance and Production Readiness.

Deep evidence: `15-NEXA-ACADEMIC-AND-FOUNDATIONAL-SOURCES.zip` and `19-NEXA-MOBILE-CONSTRUCTION-SOURCES.zip`.
