# Strategic DDD Context Map and Events

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 01-shared/domain/strategic-ddd; 01-shared/domain/processes; 01-shared/domain/bounded-contexts
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

The accepted Strategic DDD model has exactly 11 Bounded Contexts:

1. BC-01 Tenant & Access Governance
2. BC-02 Customer & Buyer Relationships
3. BC-03 Catalog & Commercial Policy
4. BC-04 Sales Commitment
5. BC-05 Inventory Availability
6. BC-06 Fulfillment & Delivery
7. BC-07 Credit & Receivables
8. BC-08 Payments
9. BC-09 Business Documents
10. BC-10 Notifications
11. BC-11 Business Traceability

Stable cross-context identities communicate ownership; they do not create cross-context relational ownership. Atomic same-context invariants use local contracts. Committed facts cross boundaries through explicit contracts and reliable outbox/inbox behavior. Deep evidence: `17-NEXA-DDD-UML-AND-DOMAIN-STORIES-CANONICAL.zip`.
