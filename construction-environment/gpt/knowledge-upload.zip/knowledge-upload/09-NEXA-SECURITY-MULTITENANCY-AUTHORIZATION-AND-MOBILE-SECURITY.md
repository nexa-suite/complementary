# Security, Multitenancy, Authorization and Mobile Security

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 01-shared/security; 01-shared/engineering/quality; 03-mobile/architecture
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

Security is defense in depth: authentication, authorization, object-level authorization, explicit Tenant/Workspace context, server-side predicates, PostgreSQL RLS and isolation tests. Workers reconstruct explicit SYSTEM scope and clean it afterward.

The mobile verification profile is aligned to OWASP MASVS without claiming certification: STORAGE, CRYPTO, AUTH, NETWORK, PLATFORM, CODE, PRIVACY and later RESILIENCE evidence are mapped to construction checks. Use platform crypto and protected storage boundaries; never home-grown crypto. Do not log raw access/refresh tokens, payment secrets, full sensitive payloads or unnecessary PII.

Camera, intents, external navigation and deep links require explicit platform handling. Security Audit stays separate from Business Traceability.
