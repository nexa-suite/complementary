# Integration Events, Reliability and Observability

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 01-shared/architecture; 01-shared/domain/processes; 01-shared/data
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

Committed facts can be propagated asynchronously only after authoritative transaction commit. The local transaction is: begin; business mutations; outbox insert; commit. Later, a publisher reads committed outbox data and publishes at-least-once. No Dynamic View may show commit followed by outbox persistence.

Consumers use idempotency/inbox or deduplication appropriate to their contract. External provider I/O is not held inside long database transactions unless explicitly justified. Transaction A persists/claims intent, then commits; external I/O follows; transaction B finalizes through fenced/idempotent logic.

Client telemetry (crash, latency, retry, timeout, unknown-result, scanner/evidence failure) is distinct from Business Traceability and Security Audit. Use correlation identifiers across client, API, transaction, outbox and worker without logging secrets or unnecessary PII.
