# Data, PostgreSQL, RLS, Concurrency and Idempotency

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 01-shared/data; 01-shared/domain/bounded-contexts/*/data
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

There is one authoritative PostgreSQL TARGET model: 95 current tables (90 owned by the 11 BCs and 5 shared technical tables). Web and Mobile do not own separate server databases. Mobile local persistence is not PostgreSQL authority.

Tenant/workspace predicates, database RLS classification and scoped candidate keys defend isolation; application correctness alone is insufficient. Same-scope root or bridge links use composite scoped foreign keys where practical. Parent-derived children document inherited scope rather than mechanically duplicating it.

Examples: membership_role joins WorkforceMembership and workspace-scoped RoleDefinition; DocumentNumberSeries is unique on `(tenant_id, workspace_id, document_type, series_code)`; current PushSubscription persists `provider_token_hash`, not raw provider tokens or `provider_endpoint_reference`.

The current tactical-to-SQL matrix names an actual guard for each mutable root. Do not add cosmetic version columns. Idempotency, revision guards, conditional updates and locks are selected by the invariant.
