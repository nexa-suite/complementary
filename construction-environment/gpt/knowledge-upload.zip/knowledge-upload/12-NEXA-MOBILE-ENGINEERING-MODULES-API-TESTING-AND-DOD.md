# Mobile Engineering Modules, API, Testing and Definition of Done

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 03-mobile/architecture/technical; 01-shared/engineering/quality; 01-shared/design
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

Mobile API translation is: OpenAPI/server contract → remote DTO → remote data source/service → repository → client application model → UI model/UiState. Generated API classes and remote DTOs do not escape into presentation.

Commands handle Problem Details, Idempotency-Key, If-Match/expected revision, correlation identifiers, 401/403/404 scope-safe behavior, 409 conflict, 412 stale state, retryable versus terminal failures, network failure, timeout and unknown outcome. Authoritative server confirmation establishes business success.

Every commit: unit/repository-use-case tests, static analysis, architecture fitness checks and lint. Pull request adds feature/component/Compose/widget/API contract checks. Sprint candidate adds emulator/simulator E2E, integrated API, interruption/retry/conflict and authorization cases. V1 acceptance adds physical Android/iOS evidence when applicable, scanner, network, accessibility, security, measured performance and system E2E. No coverage or performance number is invented.

Definition of Done requires applicable story/AC traceability, layer compliance, server authority, authorization, tests, accessibility, error/loading/empty/stale/conflict states, retry/idempotency, no secret/PII leakage, device fallback and current evidence. It is not Product Acceptance, System Acceptance or Production Readiness.
