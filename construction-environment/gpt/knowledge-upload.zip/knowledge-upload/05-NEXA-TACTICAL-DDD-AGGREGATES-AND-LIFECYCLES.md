# Tactical DDD Aggregates and Lifecycles

- generated-at: 2026-09-21T14:08:22Z
- blueprint-source-commit: ee3aaaf3c55bc0a4dfa5706a2ef82171970133db
- blueprint-source-paths: 01-shared/domain/bounded-contexts/*/tactical-model.md; diagrams/domain-model.puml
- source-status: CURRENT CANONICAL BLUEPRINT SUMMARY

Aggregate boundaries are current Blueprint decisions, not client models.

- BC-01: Tenant, HumanIdentity, WorkforceMembership, **workspace-scoped RoleDefinition**, CompanyOnboardingRequest.
- BC-02: CustomerAccount, BuyerRelationship.
- BC-03: Product, SKU, PriceList, CustomerTerms, Promotion.
- BC-04: RequestDraft, PurchaseRequest, CommercialCommitment, SalesOrder.
- BC-05: Warehouse, InventoryLot, InventoryPosition, InventoryReservation, PhysicalAllocation, WarehouseTransfer. WarehouseBacking is InventoryReservation-owned, not an Aggregate Root.
- BC-06: Fulfillment, Delivery, ProofOfDelivery, TemperatureEvidence.
- BC-07: CreditAccount, CreditReservation, Receivable, FinancialAdjustment.
- BC-08: Payment, PaymentReconciliationCase.
- BC-09: DocumentNumberSeries, BusinessDocument.
- BC-10: NotificationTemplate, Notification, NotificationPreference. PushSubscription is a technical/application delivery record, not an Aggregate Root.
- BC-11: BusinessTraceabilityRecord.

Lifecycle sources and generated UML are deep evidence in ZIP 17. Do not duplicate this model in Android or Flutter.
